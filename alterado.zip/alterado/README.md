# trab2-aoc

Dentro da pasta TESTES tem tudo que foi implementado e compilado sem erros pelo quartus
